module.exports = {
 //... 
 externals: { 
            'jquery': '$', 
            'axios':'axios' 
            };
}