<template>
	<div class="seed1">
		<div class="seed1_1">
			小魔熊-设计品牌IP形象
		</div>
		<div class="seed1_2">
			<span>2天前</span>
		</div>
		<div class="seed1_3">
			原创-平面-品牌
		</div>
	</div>
</template>

<script>
</script>

<style>
</style>
