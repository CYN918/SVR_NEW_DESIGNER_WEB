<template>	
	<div class="activvit">
		<list :config="data">
			<template v-slot:todo="{ todo }">
				<div class="ac_list_Box_0" @click="go(todo.id)">
					<div class="ac_list_Box_2x"><img class="ac_list_Box_1" :src="todo.banner" alt=""></div>					
					<div class="ac_list_Box_2">
						<div class="ac_list_Box_4">{{todo.activity_name}}</div>
						<div class="ac_list_Box_5"><span>{{todo.category_name}}</span>投稿时间：{{todo.start_time.split(" ")[0]}} 至 {{todo.end_time.split(" ")[0]}}</div>
						<div class="ac_list_Box_3">
							<span v-if="todo.status==1" class="ac_list_Box_6">{{todo.left_day==0?'今':todo.left_day}}天</span><span v-if="todo.status==1" class="ac_list_Box_7">距离截止</span>
							<span v-else-if="todo.status==-1" class="ac_list_Box_8">已结束</span>
						</div>
					</div>
				</div>
			</template>			
		</list>
		
	</div>
</template>

<script>
import list from '../../components/list';
export default {
	components:{list},
	name: 'activvity_list',	 
	data(){	
		return{
			data:{
				ajax:{
					url:'a_getList',
				}
			},	
		}		
	},
	methods:{		
		go(id){
			this.$router.push({path:'/detailed',query:{id:id}});	
		}
	},
	
	
	
}
</script>

<style>
.activvit .listBox{
	margin-top: 20px;
}
.activvit .listBox>li:nth-child(2n+2)>div{
	margin-right: 0;
}
.ac_list_Box_0{
	background: #F6F6F6;
	border-radius: 5px;
	margin: 0 20px 20px 0;
	width: 640px;
	height: 460px;
}

.ac_list_Box_2{
	position: relative;
	padding: 22px 20px 23px;
}
.ac_list_Box_4{
	font-size: 16px;
	color: #1E1E1E;
	margin-bottom: 14px;
}
.ac_list_Box_5{
	font-size: 14px;
	color: #999999;
}
.ac_list_Box_5>span{
    font-size: 12px;
    color: #999999;
    padding: 5px 10px;
    background: #E6E6E6;
    border-radius: 2px;
	margin-right: 10px;
}
.ac_list_Box_3{
	position: absolute;
	bottom: 26px;
	right: 20px;
	text-align:right;
}
.ac_list_Box_6{
	display: block;
	font-size: 16px;
	color: #1D1D1D;
	margin-bottom: 4px;
}
.ac_list_Box_7{
	font-size: 14px;
	color: #999999;
}
.ac_list_Box_8{
	display: inline-block;
	font-size: 16px;
	color: #999999;
	margin-bottom: 12px;
}
.ac_list_Box_2x{
	position: relative;
	border-radius: 5px 5px 0 0;
	overflow: hidden;
	display: block;
	width: 100%;
	height: 360px;
}
.ac_list_Box_1{
	position: absolute;
	top: 50%;
	left: 50%;
    -webkit-transform: translate(-50%,-50%);
    transform: translate(-50%,-50%);
	display: block;
	min-width: 100%;
	min-height:100%;
}
</style>
