import login from './login.vue';
const Login = {
    install:function(Vue) {
        Vue.component('Login',login)
    }
}
export default Login;