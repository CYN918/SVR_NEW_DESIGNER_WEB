import Follow from './follow.vue';

const loading = {
    install:function(Vue) {
        Vue.component('Follow', Follow)
    }
}

export default Follow;