<template>
	<div class="kBg_01">
		<!-- <img src="https://static.zookingsoft.com/SVR_NEW_DESIGNER_WEB/img/k/empty_nodata@3x.png"/>
		*  -->
		<img src="https://static.zookingsoft.com/SVR_NEW_DESIGNER_WEB/img/svg/empty_nodata.svg" alt="">
		你的数据去火星了
	</div>
</template>

<script>
</script>

<style>
.kBg_01{
	position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    text-align: center;
    width: 100%;
    font-size:14px;
	font-family:PingFangSC-Regular;
	font-weight:400;
	color:rgba(153,153,153,1);
	line-height:24px;
    
}
.kBg_01>img{
	display: block;
	width: 100%;
	margin-bottom: 15px;

}	
</style>