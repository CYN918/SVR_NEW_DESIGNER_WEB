<template>
    <div>
        <div class="nav_rig" v-if="visualWidth" @mouseleave="mouseLeave('g')" style="height:300px;">
            <ul>
                <li class="nav_logo" @mouseenter="mouseover('e')" @mouseleave="mouseLeave('e')"><img :src="imgSig+'newHome/ip.svg'" alt=""/></li>
                <li class="nav_upload" v-if="uploadShow" @click="upload()" @mouseenter="mouseover('c')" @mouseleave="mouseLeave('c')"><img class="nav_upload_img" :src="imgSig+'newHome/upload.svg'" alt=""/><p>上传作品</p></li>
                <li class="nav_upload" v-else @click="upload()" @mouseenter="mouseover('c')" @mouseleave="mouseLeave('c')"><img class="nav_upload_img" :src="imgSig+'newHome/bar_icon_upload.svg'" alt=""/><p>上传作品</p></li>
                <li class="nav_tolt" v-if="totalShow" @mouseenter="mouseover('d')" @mouseleave="mouseLeave('d')"><img :src="imgSig+'newHome/icon-earning-black.svg'" alt=""/><p>去赚钱</p></li>
                <li class="nav_tolt" v-else @mouseenter="mouseover('d')" @mouseleave="mouseLeave('d')"><img :src="imgSig+'newHome/icon-earning-money.svg'" alt=""/><p>去赚钱</p></li>
                <li class="nav_weixin" @mouseenter="mouseover('a')" @mouseleave="mouseLeave('a')"><img :src="imgSig+'newHome/icon-ewm-small.png'" alt=""/><p>微信公众号</p></li>
                <li class="nav_weibo" @click="go_weibo()">官方微博</li>
                <li class="nav_top" @click="go_top()" v-if="isShow">TOP</li>
            </ul>
            <div class="nav_tolt_hover" @mouseenter="mouseover('d')" @mouseleave="mouseLeave('d')">
                <img :src="imgSig+'newHome/icon-zq-hover.svg'" alt=""/>
                <button class="nav_tolt_hover_btn" @click="go_tolt()">点我赚钱</button>
            </div>
            <div class="nav_weixin_hover" @mouseenter="mouseover('a')" @mouseleave="mouseLeave('a')">
                <img :src="imgSig+'newHome/icon-ewm-big.png'" alt=""/>
                <p>微信公众号</p>
            </div>
        </div>
        <div class="nav_rig" v-if="visualWidth_2">
            <ul>
                <li class="nav_logo" @mouseenter="mouseover('e')" @mouseleave="mouseLeave('e')"><img :src="imgSig+'newHome/ip.svg'" alt=""/></li>
                <li class="nav_upload" v-if="uploadShow" @click="upload()" @mouseenter="mouseover('c')" @mouseleave="mouseLeave('c')"><img class="nav_upload_img" :src="imgSig+'newHome/upload.svg'" alt=""/><p>上传作品</p></li>
                <li class="nav_upload" v-else @click="upload()" @mouseenter="mouseover('c')" @mouseleave="mouseLeave('c')"><img class="nav_upload_img" :src="imgSig+'newHome/bar_icon_upload.svg'" alt=""/><p>上传作品</p></li>
                <li class="nav_tolt" v-if="totalShow" @mouseenter="mouseover('d')" @mouseleave="mouseLeave('d')"><img :src="imgSig+'newHome/icon-earning-black.svg'" alt=""/><p>去赚钱</p></li>
                <li class="nav_tolt" v-else @mouseenter="mouseover('d')" @mouseleave="mouseLeave('d')"><img :src="imgSig+'newHome/icon-earning-money.svg'" alt=""/><p>去赚钱</p></li>
                <li class="nav_weixin" @mouseenter="mouseover('a')" @mouseleave="mouseLeave('a')"><img :src="imgSig+'newHome/icon-ewm-small.png'" alt=""/><p>微信公众号</p></li>
                <li class="nav_weibo" @click="go_weibo()">官方微博</li>
                <li class="nav_top" @click="go_top()" v-if="isShow">TOP</li>
            </ul>
            <div class="nav_tolt_hover" @mouseenter="mouseover('d')" @mouseleave="mouseLeave('d')">
                <img :src="imgSig+'newHome/icon-zq-hover.svg'" alt=""/>
                <button class="nav_tolt_hover_btn" @click="go_tolt()">点我赚钱</button>
            </div>
            <div class="nav_weixin_hover" @mouseenter="mouseover('a')" @mouseleave="mouseLeave('a')">
                <img :src="imgSig+'newHome/icon-ewm-big.png'" alt=""/>
                <p>微信公众号</p>
            </div>
        </div>
        <div class="nav_rig_1" v-if="visualWidth_1">
            <ul @mouseenter="mouseover('g')">
                <li class="nav_logo_1"><img :src="imgSig+'newHome/ip.svg'" alt=""/></li>
            </ul>
        </div>
    </div>  
</template>
<script>
export default {
    name: 'nav_right',
    data(){
        return {
            isShow:false,
            uploadShow:true,
            totalShow:true,
            visualWidth:true,
            visualWidth_1:false,
            visualWidth_2:false,
        }
    },
    mounted: function(){
        window.addEventListener('scroll',this.scrollToTop);
    }, 
    created(){
        this.getWidth();
    },
    destroyed(){
        window.removeEventListener('scroll',this.scrollToTop);
    },
    methods: {
        getWidth() {
            var winWidth;
            if(window.innerWidth) {
                winWidth = window.innerWidth;
            } else if((document.body) && (document.body.clientWidth)) {
                winWidth = document.body.clientWidth;
            }
            if(winWidth <= 1440){
                this.visualWidth = false;
                this.visualWidth_1 = true;
                this.visualWidth_2 = false;
            }else{
                this.visualWidth = false;
                this.visualWidth_1 = false;
                this.visualWidth_2 = true;
            }
         
        },
        go_top(){
            // let timer = setInterval(() => {
            //     let ispeed = Math.floor(-this.scrollTop / 5);
            //     document.documentElement.scrollTop = document.body.scrollTop = this.scrollTop + ispeed;
            //     if(this.scrollTop === 0){
            //         clearInterval(timer);
            //     }
            // },16);
            this.mJs.scTop(0);
        },
        scrollToTop(){
			this.bdtj("首页","TOP（置顶）","--")
            let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
            this.scrollTop = scrollTop;
            if(this.scrollTop > 980){
                this.isShow = true;
            }else{
                this.isShow = false;
            }
        },
        mouseover(type){
            if(type == 'd'){
                document.getElementsByClassName('nav_tolt_hover')[0].style.display = 'block'
                document.getElementsByClassName('nav_tolt')[0].style.background = '#33B3FF'
                document.getElementsByClassName('nav_tolt')[0].style.color = '#ffffff'
                this.totalShow = false;
            }
            if(type == 'a'){
                document.getElementsByClassName('nav_weixin_hover')[0].style.display = 'block'
            }  
            if(type == 'c'){
                document.getElementsByClassName('nav_upload')[0].style.background = '#33B3FF'
                document.getElementsByClassName('nav_upload')[0].style.color = '#ffffff'
                this.uploadShow = false;
            }
            if(type == 'e'){
                document.getElementsByClassName('nav_logo')[0].style.top = '50px'
            } 
            if(type == 'g'){
                this.visualWidth = true;
                this.visualWidth_1 = false;
            } 
        },
        mouseLeave(type){
            if(type == 'd'){
                document.getElementsByClassName('nav_tolt_hover')[0].style.display = 'none'
                document.getElementsByClassName('nav_tolt')[0].style.background = '#FFFFFF'
                document.getElementsByClassName('nav_tolt')[0].style.color = '#1E1E1E'
                this.totalShow = true;
            } 
            if(type == 'a'){
                document.getElementsByClassName('nav_weixin_hover')[0].style.display = 'none'
            } 
            if(type == 'c'){
                document.getElementsByClassName('nav_upload')[0].style.background = '#FFFFFF'
                document.getElementsByClassName('nav_upload')[0].style.color = '#1E1E1E'
                this.uploadShow = true;
            }
            if(type == 'e'){
                document.getElementsByClassName('nav_logo')[0].style.top = '60px'
            } 
            if(type == 'g'){
                this.visualWidth = false;
                this.visualWidth_1 = true;
            }  
        },
        go_tolt(){
			this.bdtj("首页","去赚钱","--")
            this.$router.push({path:'/tolt'});
        },
        upload(){
			this.bdtj("首页","上传作品","--")
            this.$router.push({path:'/upload'});
        },
        go_weibo(){
			this.bdtj("首页","官方微博","--")
            window.open('https://weibo.com/shiquanerzk?is_all=1','_blank')
        },
    }  
}
</script>
<style scoped>
.nav_rig{
	width: 93.53px;
	position: fixed;
	right: 2.3%;
	top: 40%;
    z-index: 999999;
}
.nav_logo{
    height: 112px;
    position: relative;
    top: 60px;
    z-index: 0;
}
.nav_upload{
    width: 91.53px;
    height: 66px;
    background: #FFFFFF;
    color: #1E1E1E;
    font-size: 14px;
    border-top: 1px solid #0066B4;
    border-left: 1px solid #0066B4;
    border-right: 1px solid #0066B4;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    z-index: 99999;
    position: relative;
}
.nav_upload > p{
    width: 48px;
    font-size: 12px;
    border-bottom: 1px #D9D9D9 solid;
    margin: 2px auto 0px auto;
    padding-bottom: 12px;
    color: #1E1E1E;
}
.nav_tolt > p{
    width: 48px;
    font-size: 12px;
    border-bottom: 1px #D9D9D9 solid;
    margin: 2px auto 0px auto;
    padding-bottom: 10px;
    color: #1E1E1E;
}
.nav_weixin > p{
    width: 60px;
    font-size: 12px;
    border-bottom: 1px #D9D9D9 solid;
    margin: 2px auto 0px auto;
    padding-bottom: 6px;
    color: #1E1E1E;
}
.nav_tolt{
    width: 91.53px;
    height: 66px;
    z-index: 999999;
    background: #FFFFFF;
    color: #1E1E1E;
    font-size: 14px;
    border-left: 1px solid #0066B4;
    border-right: 1px solid #0066B4;
}
.nav_upload > img,.nav_tolt > img{
    margin-top: 15px;
    max-width:21px;
}
.nav_weixin{
    width: 91.53px;
    height: 94px;
    border-left: 1px solid #0066B4;
    border-right: 1px solid #0066B4;
    background: #FFFFFF;
    color: #1E1E1E;
    font-size: 14px;
}
.nav_weixin > img{
    margin-top: 10px;
    max-width: 56px;
}
.nav_rig > ul > li{
	text-align: center;
    cursor: pointer;
}
.nav_rig > ul .nav_weibo:hover,.nav_rig > ul .nav_top:hover,.nav_weixin:hover{
    background: #33B3FF;
    color: #ffffff;
}
.nav_rig > ul .nav_weibo{
	width: 91.53px;
	height: 34px;
	line-height: 36px;
	color: #1E1E1E;
	font-size: 14px;
	border-left: 1px solid #0066B4;
    border-right: 1px solid #0066B4;
    border-bottom: 1px solid #0066b4;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: #FFFFFF;
}
.nav_rig > ul .nav_top{
    width: 91.53px;
	height: 34px;
	line-height: 36px;
	color: #1E1E1E;
	font-size: 14px;
	border: 1px solid #0066B4;
	border-radius: 5px;
	margin-top: 4px;
    background: #FFFFFF;
}
.nav_tolt_hover{
    width: 280px;
    height: 160px;
    position: absolute;
    right: 105%;
    top: 35%;
    display: none;
}
.nav_tolt_hover .nav_tolt_hover_btn{
    width: 120px;
    height: 40px;
    text-align: center;
    line-height: 40px;
    background: #33B3FF;
    color: #ffffff;
    font-size: 14px;
    outline: none;
    margin-left: 24px;
    float: left;
    border: none;
    cursor: pointer;
    position: relative;
    bottom: 69px;
    border-radius: 5px;
    cursor: pointer;
}
.nav_weixin_hover{
    width: 220px;
    height: 240px;
    position: absolute;
    right: 105%;
    top: 25%;
    border: 1px solid #33B3FF;
    border-radius: 5px;
    background: #FFFFFF;
    padding: 5px;
    display: none;
    cursor: pointer;
}
.nav_weixin_hover > img{
    margin-top: 15px;
}
.nav_weixin_hover > p{
    font-size: 14px;
    color: #1E1E1E;
    text-align: center;
}
@media (max-width: 1440px){
    .nav_rig_1{
        position: fixed;
        right: -3%;
        top: 40%;
        z-index: 999999;
        cursor: pointer;
        width: 95px;
        height: 800px;
    }
    .nav_logo_1{
        transform:rotate(-53deg);
        -ms-transform:rotate(-53deg); /* Internet Explorer */
        -moz-transform:rotate(-53deg); /* Firefox */
        -webkit-transform:rotate(-53deg); /* Safari 和 Chrome */
        -o-transform:rotate(-53deg); /* Opera */
    }
}
</style>