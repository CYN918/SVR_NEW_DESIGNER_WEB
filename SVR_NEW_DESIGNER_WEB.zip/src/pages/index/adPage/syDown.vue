<template>
	<div class="adpage_syD">
		<img class="adpage_syD_0" :src="setImgU('adPage/sy_01.png')"/>
		<img class="adpage_syD_01" :src="setImgU('adPage/sy_02.png?a=3')"/>
		<p class="adpage_syD_1">
			<span class="adpage_syD_2">
				<a class="adpage_syD_3" href="https://shiquaner.zookingsoft.com/#/cont?id=159038746021">什么是来电秀?</a>
				<span class="adpage_syD_4">
					<a href="http://www.zookingsoft.com/">© 2015-2019 深圳掌酷软件有限公司</a><i></i>
					<a href="http://beian.miit.gov.cn">粤ICP备15039011号</a><i></i>
					<a href="http://www.beian.gov.cn"><img class="adpage_syD_4_1" :src="setImgU('svg/footer_ga.png')"/>粤公网安备 44030502004296号</a>
				</span>
			</span>
			<span class="adpage_syD_2 adpage_syD_2x">
				<img class="adpage_syD_5" :src="setImgU('adPage/sy_02.png?a=3')"/>
				<span class="adpage_syD_6">扫码下载 <span>狮映APP</span></span>
			</span>
			
		</p>
	</div>
</template>

<script>
</script>

<style scoped="scoped">
.adpage_syD_0{
	display: block;
	width: 100%;
}
.adpage_syD_1{
	display: block;
	width: 100%;
	height:182px;
	background:rgba(24,24,24,1);
	text-align: center;
}
.adpage_syD_2{
	display: inline-block;
	vertical-align: top;
}
.adpage_syD_01{
	position: absolute;
	top: 0;
	right: 35%;
	width: 8.33%;
	padding-top: 20%;

}
.adpage_syD_3{
	display: block;
	text-align: left;
	margin: 61px 0 24px;
	font-size:16px;
	color:rgba(255,255,255,1);
	line-height:24px;
}
.adpage_syD_4>a{
	display: inline-block;
	vertical-align: top;
	font-size:14px;
	color:rgba(255,255,255,1);
	line-height:20px;
}
.adpage_syD_4>i{
	display: inline-block;
	margin: 2px 24px;
	vertical-align: top;
	width:1px;
	height:16px;
	background:rgba(244,246,249,.5);
}
.adpage_syD_4_1{
	display: inline-block;
	vertical-align: top;
	width: 16px;
	margin: 1.5px 6px 0 0;
}
.adpage_syD_2x{
	margin-left: 80px;
}
.adpage_syD_5{
	display: block;
	width: 100px;
	height: 100px;
	margin: 41px 0 8px;
}
.adpage_syD_6{
	font-size:12px;
	color:rgba(255,255,255,1);
	line-height:18px;
}
.adpage_syD_6>span{
	color: #FF9200;
}
</style>
