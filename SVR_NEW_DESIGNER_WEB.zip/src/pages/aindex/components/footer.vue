<template>
	<footer class="footerBox">
		<div class="footerlog">
			<img class="log" src="/imge/app/log.png" alt="">狮大大
		</div>
		<div class="footer_1">发现更多有价值的创意</div>
		<div class="footer_2">Copyright @2019 SHIQUANER</div>
		<div class="footer_3">PC登录狮圈儿，寻找更多好作品</div>
	</footer>
</template>
<script>

export default {
     
	    data(){
	        return {
	         	
			}
		},
		methods:{
		
		},
	}
</script>

<style>
.footerBox{

    width: 100%;
    height: 7.82rem;
	text-align: center;
	color: #fff;
	box-sizing: border-box;
    padding: .4rem 0;
    background: #ff5121;
}
.footerlog{
	font-size: .7rem;
	
}
.footer_1{font-size: .5rem;margin-bottom: .7rem;}
.footer_2{font-size: .35rem;margin-bottom: .9rem;}
.footer_3{
    width: 14.3rem;
    height: 1.8rem;
    background: #ff5121;
    margin: 0 auto;

    font-size: .776rem;
    line-height: 1.8rem;

}
</style>
